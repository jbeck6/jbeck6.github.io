import sqlite3
from flask import Flask, request, session, g, redirect, url_for, abort, \
     render_template, flash, json
#from flask_bootstrap import Bootstrap


def create_app():
  app = Flask(__name__)
 # Bootstrap(app)
  app.debug = True
  app.secret_key = 'dev_key'
  return app

def init(app):
  #before every request from the browser
  @app.before_request
  def before_request():
	g.db = sqlite3.connect('../Database/cbpower.db')

  #close database after every request
  @app.teardown_request
  def teardown_request(exception):
	  if hasattr(g, 'db'):
		g.db.close()

  def getKey(item):
	return item[1]

  @app.route('/', methods=['POST', 'GET'])
  def index():
      rankings = g.db.execute('select * from ratings').fetchall()
      rankings = sorted(rankings, key = getKey, reverse=True)
      team_list = []
      week = []
      week_rankings = g.db.execute('select * from weekrank').fetchall()
      teams = []
      for team in week_rankings:
        t = [team[1]]
        for i in range(2, len(team)):
          t.append(team[i])
        teams.append(t)
      week = []
      for team in teams:
        week.append([team[0], team[1:]])
        team_list.append(team[0])
      if(request.method == 'GET'):
        return render_template('main.html', rankings =rankings)
      if(request.method == 'POST'):
        if (request.form['team_search'] in team_list):
          return render_template('team.html', rankings=rankings, season_rankings=map(json.dumps,week), team = request.form['team_search']);
        else:
          return render_template('error.html', team = request.form['team_search']);
  @app.route('/graph')
  def graph():
    week_rankings = g.db.execute('select * from weekrank').fetchall()
    teams = []
    for team in week_rankings:
      t = [team[1]]
      for i in range(2, len(team)):
        t.append(team[i])
      teams.append(t)
    week = []
    for team in teams:
      week.append([team[0], team[1:]])
    
    rankings = g.db.execute('select * from ratings').fetchall()
    rankings = sorted(rankings, key = getKey, reverse=True)
    return render_template('graph.html', rankings=rankings,season_rankings=map(json.dumps,week)); 

if __name__ == '__main__':
    app = create_app()
    init(app)
    app.run()
