import elo
import math
import sqlite3 as lite
from datetime import date

#team1 = ( 1320 )
#team2 = ( 1740 )

#Create current ratings table in db
db = lite.connect('../Database/cbpower.db')
db.execute("DROP TABLE IF EXISTS ratings")
db.execute("CREATE TABLE ratings(team_name text not null, rate float not null, wins integer, losses integer)")
db.commit()
cursor = db.cursor()
cursor.execute("SELECT *, strftime('%w',date) FROM games")
results = cursor.fetchall()

#Create timestamp table
db.execute("DROP TABLE IF EXISTS weekrank")
db.execute("""CREATE TABLE weekrank (
id INTEGER primary key  AUTOINCREMENT,
team_name text, 
'1' float, '2' float, '3' float, '4' float, '5' float, '6' float,
'7' float, '8' float, '9' float, '10' float, '11' float, '12' float,
'13' float, '14' float, '15' float, '16' float, '17' float,
'18' float, '19' float, '20' float, '21' float);""")
db.commit()

#Create vairable to track which is the current timestamp
time = 2 #1 contains init rankings so begin at 2 (Should've started at 0, but trying to not rewrite SQL)

#dictionary to hold each key (school name) and value (elo ranking)
rankings = {}

#dicts to hold wins and losses
wins = {}
losses = {}

lastday = results[0][6] #Holds previous row (Only store weekly rankings on first game on Sunday)
for row in results:
	weekday = row[6]
	home_team = row[2]
	home_score = row[3]
	away_team = row[4]
	away_score = row[5]

	#if the team is not in the ratings db, add it and initialize with a rating of 1500
	cursor.execute("SELECT * FROM ratings WHERE team_name = ?", (home_team,))
	if len(cursor.fetchall()) <= 0:
		cursor.execute('INSERT INTO ratings (team_name, rate, wins, losses) VALUES (?, ?, ?, ?)', (home_team, 1500,0,0))

	cursor.execute("SELECT * FROM ratings WHERE team_name = ?", (away_team,))
	if len(cursor.fetchall()) <= 0:
		cursor.execute('INSERT INTO ratings (team_name, rate, wins, losses) VALUES (?, ?, ?, ?)', (away_team, 1500,0,0))

	#If team isn't in the weekrank table then add it 
	cursor.execute("SELECT * FROM weekrank WHERE team_name = ?", (home_team,))
	if len(cursor.fetchall()) <= 0:
		cursor.execute("INSERT INTO weekrank (team_name, '1') VALUES (?, ?)", (home_team, 1500))

	cursor.execute("SELECT * FROM weekrank WHERE team_name = ?", (away_team,))
	if len(cursor.fetchall()) <= 0:
		cursor.execute("INSERT INTO weekrank (team_name, '1') VALUES (?, ?)", (away_team, 1500))



	#add each team to the dict if it's not in there already
	if not rankings.has_key(home_team):
		rankings[home_team] = 1500
		wins[home_team] = 0
		losses[home_team] = 0
	if not rankings.has_key(away_team):
		wins[away_team] = 0
		losses[away_team] = 0
		rankings[away_team] = 1500
	
	#If row.day==Sunday AND lastrow.day==saturday store current rankings
	#row_date = cursor.execute("SELECT strftime('%w', ?)", (date,)).fetchall()
	#prevRow_date = cursor.execute("SELECT strftime('%w', ?)", (lastrow[1],)).fetchone()
	weekday = str(weekday)
	lastday = str(lastday)
	if((weekday=='0') and (lastday=='6')):
		print "Updating " + "time=" + str(time)
		for team in rankings:
			name = str(team)
			rank = rankings[team]
			cursor.execute("UPDATE weekrank SET {} = ? WHERE team_name == ?".format("'" + str(time) + "'"), (rank, name))
		time = time + 1

	home_rank = ( rankings.get(home_team) )
	away_rank = ( rankings.get(away_team) )

	#Continue processing games and updating rankings`
	if home_score > away_score:
		final_ranks = elo.rate_1vs1(home_rank, away_rank)
		rankings[home_team] = final_ranks[0]
		rankings[away_team] = final_ranks[1]

		#Update w/l
		wins[home_team] = wins[home_team] + 1
		losses[away_team] = losses[away_team] + 1
	else:
		final_ranks = elo.rate_1vs1(away_rank, home_rank)
		rankings[home_team] = final_ranks[1]
		rankings[away_team] = final_ranks[0]
	
		#Update w/l
		wins[away_team] = wins[away_team] + 1
		losses[home_team] = losses[home_team] + 1

	lastday = row[6]
 
for team in rankings:
	name = team
	rank = rankings[team]
	cursor.execute("UPDATE ratings SET rate = ? WHERE team_name == ?", (rank, name))
	cursor.execute("UPDATE ratings SET wins = ? WHERE team_name == ?", (wins[team], name))
	cursor.execute("UPDATE ratings SET losses = ? WHERE team_name == ?", (losses[team], name))
db.commit()

