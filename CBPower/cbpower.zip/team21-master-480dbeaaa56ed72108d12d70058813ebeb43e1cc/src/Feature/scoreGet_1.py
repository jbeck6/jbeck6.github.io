import urllib2
import re
import datetime
import sqlite3 as lite

#Get game data from kenpom website
response = urllib2.urlopen('http://www.kenpom.com/cbbga16.txt')
html = response.read()

#Use regex to parse raw game data
pattern = r"(\d{2}\/\d{2}\/\d{4})\s([\w,',.]+?\s?[\w,',.,&]*\s?[\w,',.,&]*\s?[\w,',.,&]+?)\s{2,}(\d{2,3})\s([\w,',.,&]*\s?[\w,',.,&]*\s?[\w,',.,&,]*\s?[\w,',.,&,]+)\s{2,}(\d{2,3})"

regex = re.compile(pattern, re.DOTALL)

#Setup database
db = lite.connect('../Database/cbpower.db')

#Drop old table and create new table to hold game data
db.execute("DROP TABLE IF EXISTS games")
db.execute("CREATE TABLE games(id integer primary key autoincrement, date text not null, home_team text not null, home_score integer not null, away_team text not null, away_score integer not null)")
db.commit()

#Addgame data to the db
for match in regex.finditer(html):
	tmptime = datetime.datetime.strptime(match.group(1), "%m/%d/%Y")
	newdate = tmptime.strftime("%Y-%m-%d")
	db.execute('INSERT INTO games (date, home_team, home_score, away_team, away_score) VALUES (?, ?, ?, ?, ?)', [str(newdate), str(match.group(2)), str(match.group(3)),str(match.group(4)), str(match.group(5))])

db.commit()

