import urllib2
import re
import datetime
import mysql.connector

#Get game data from kenpom website
response = urllib2.urlopen('http://www.kenpom.com/cbbga16.txt')
html = response.read()

#Use regex to parse raw game data
pattern = r"(\d{2}\/\d{2}\/\d{4})\s([\w,',.]+?\s?[\w,',.,&]*\s?[\w,',.,&]*\s?[\w,',.,&]+?)\s{2,}(\d{2,3})\s([\w,',.,&]*\s?[\w,',.,&]*\s?[\w,',.,&,]*\s?[\w,',.,&,]+)\s{2,}(\d{2,3})"

regex = re.compile(pattern, re.DOTALL)

#Setup database
db = mysql.connector.connect(host="mysql.utk.edu",user="aseal",passwd="teamjacob123!",db="aseal_tmjacob")
cur = db.cursor()

#Drop old table and create new table to hold game data
cur.execute("DROP TABLE IF EXISTS games")
cur.execute("CREATE TABLE games(date DATE, hometeam varchar(40),homescore INT, awayteam varchar(40), awayscore INT)")

#Addgame data to the db
for match in regex.finditer(html):
	tmptime = datetime.datetime.strptime(match.group(1), "%m/%d/%Y")
	newdate = tmptime.strftime("%Y/%m/%d")
	com = 'INSERT INTO games (date, hometeam, homescore, awayteam, awayscore) VALUES ("' + str(newdate) + '","' + str(match.group(2)) + '","' + str(match.group(3)) + '","' + str(match.group(4)) + '","' + str(match.group(5)) + '")'
	print com
	cur.execute(com)
	print "%s %s %s %s %s" % (newdate, match.group(2), match.group(3), match.group(4), match.group(5))



