drop table if exists games;

create table games (
	id integer primary key autoincrement,
	date text not null,
	home_team text not null,
	home_score integer not null,
	away_team text not null,
	away_score integer not null
);

create table rankings(
	rank integer primary key autoincrement,
	team_name text not null
);
